package ui;

import model.Student;
import service.CSVReaderService;
import service.StudentAnalysisService;
import util.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("Student Performance Analytics Dashboard");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(245, 245, 245));
        setLayout(new BorderLayout(10, 10));

        // Load students
        List<Student> students = CSVReaderService.readStudentsCSV(
                "C:/Users/agorv/Desktop/project 1_java/SubjectAnalyzer/src/main/students.csv");

        // KPI Panel
        JPanel kpiPanel = createKPIPanel(students);
        add(kpiPanel, BorderLayout.NORTH); // KPI at top

        // Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(new Color(245, 245, 245));

        // Tab 1: Blue bar chart for average score per subject
        tabs.add("Subject Performance", ChartUtils.subjectChartAllSubjects(students));

        // Tab 2: Pass/Fail stacked bar chart
        tabs.add("Pass / Fail", PassFailChart.create(students));

        // Tab 3: Top Students table
        tabs.add("Top  10 Students", TopStudentsTable.create(students));

        // Tab 4: Study Hours analysis
        tabs.add("Study Hours Analysis", StudyHoursChart.create(students));

        // Tab 5: CSV Content table
        tabs.add("CSV Content", CSVContentTable.create(students));
        // Tab 6: Grade Distribution Pie Chart
        tabs.add("Grade Distribution", GradeDistributionChart.create(students));

        add(tabs, BorderLayout.CENTER);

        setVisible(true);
    }

    private JPanel createKPIPanel(List<Student> students) {
        JPanel panel = new JPanel(new GridLayout(1, 4, 20, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(new Color(245, 245, 245));
        panel.setPreferredSize(new Dimension(1000, 120));

        int total = students.size();
        double avgScore = students.stream().mapToDouble(Student::getAverageScore).average().orElse(0);
        long pass = students.stream().filter(s -> s.getAverageScore() >= 50).count();
        double passRate = (pass * 100.0) / total;
        Student top = StudentAnalysisService.topStudent(students);

        panel.add(createCard("Total Students", String.valueOf(total), new Color(52, 152, 219)));
        panel.add(createCard("Average Score", String.format("%.2f", avgScore), new Color(46, 204, 113)));
        panel.add(createCard("Pass Rate", String.format("%.1f%%", passRate), new Color(241, 196, 15)));
        panel.add(createCard("Top Student", top != null ? top.getName() : "N/A", new Color(231, 76, 60)));

        return panel;
    }

    private JPanel createCard(String title, String value, Color bgColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(bgColor);
        card.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2, true));
        card.setPreferredSize(new Dimension(150, 100));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setHorizontalAlignment(JLabel.CENTER);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 18));

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}