package service;

import model.Student;

import java.util.List;

public class StudentAnalysisService {

    public static double avgMath(List<Student> s){
        return s.stream().mapToDouble(Student::getMaths).average().orElse(0);
    }

    public static double avgEnglish(List<Student> s){
        return s.stream().mapToDouble(Student::getEnglish).average().orElse(0);
    }

    public static double avgScience(List<Student> s){
        return s.stream().mapToDouble(Student::getScience).average().orElse(0);
    }

    public static double avgSocial(List<Student> s){
        return s.stream().mapToDouble(Student::getSocial).average().orElse(0);
    }

    public static Student topStudent(List<Student> s){

        return s.stream()
                .max((a,b)->Double.compare(a.getAverageScore(),b.getAverageScore()))
                .orElse(null);
    }
}