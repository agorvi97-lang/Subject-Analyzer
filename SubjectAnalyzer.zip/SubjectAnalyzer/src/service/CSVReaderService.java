package service;

import model.Student;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class CSVReaderService {

    public static List<Student> readStudentsCSV(String path){

        List<Student> students = new ArrayList<>();

        try{

            BufferedReader br = new BufferedReader(new FileReader(path));

            String line;

            br.readLine();

            while((line=br.readLine())!=null){

                String[] data=line.split(",");

                students.add(new Student(

                        data[0],
                        data[1],
                        Double.parseDouble(data[2]),
                        Double.parseDouble(data[3]),
                        Double.parseDouble(data[4]),
                        Double.parseDouble(data[5]),
                        Double.parseDouble(data[6]),
                        Double.parseDouble(data[7])

                ));
            }

            br.close();

        }catch(Exception e){
            e.printStackTrace();
        }

        return students;
    }
}