package util;

import model.Student;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PassFailChart {

    public static JPanel create(List<Student> students) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        String[] subjects = {"Maths", "English", "Science", "Social"};

        for (String subject : subjects) {
            long pass = students.stream()
                    .filter(s -> s.getScore(subject) >= 50)
                    .count();
            long fail = students.stream()
                    .filter(s -> s.getScore(subject) < 50)
                    .count();

            // Cast to double to avoid lossy conversion error
            dataset.addValue((double) pass, "Pass", subject);
            dataset.addValue((double) fail, "Fail", subject);
        }

        // Create stacked bar chart
        JFreeChart chart = ChartFactory.createStackedBarChart(
                "Pass / Fail per Subject",
                "Subject",
                "Number of Students",
                dataset
        );

        CategoryPlot plot = chart.getCategoryPlot();
        StackedBarRenderer renderer = new StackedBarRenderer();

        // Colors: Green = Pass, Red = Fail
        renderer.setSeriesPaint(0, new Color(46, 204, 113));
        renderer.setSeriesPaint(1, new Color(231, 76, 60));

        plot.setRenderer(renderer);
        plot.setBackgroundPaint(new Color(245, 245, 245));

        return new ChartPanel(chart);
    }
}