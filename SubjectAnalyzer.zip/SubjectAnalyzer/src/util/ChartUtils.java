package util;

import model.Student;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ChartUtils {

    // Blue Bar Chart showing average score per subject with value labels
    public static JPanel subjectChartAllSubjects(List<Student> students) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        double avgMaths = students.stream().mapToDouble(Student::getMaths).average().orElse(0);
        double avgEnglish = students.stream().mapToDouble(Student::getEnglish).average().orElse(0);
        double avgScience = students.stream().mapToDouble(Student::getScience).average().orElse(0);
        double avgSocial = students.stream().mapToDouble(Student::getSocial).average().orElse(0);

        dataset.addValue(avgMaths, "Average Score", "Maths");
        dataset.addValue(avgEnglish, "Average Score", "English");
        dataset.addValue(avgScience, "Average Score", "Science");
        dataset.addValue(avgSocial, "Average Score", "Social");

        JFreeChart chart = ChartFactory.createBarChart(
                "Average Score by Subject",
                "Subject",
                "Average Score",
                dataset
        );

        CategoryPlot plot = chart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(52, 152, 219)); // blue
        renderer.setDefaultItemLabelsVisible(true);
        renderer.setDefaultItemLabelGenerator(new StandardCategoryItemLabelGenerator());

        plot.setBackgroundPaint(Color.WHITE);
        plot.setRangeGridlinePaint(Color.GRAY);

        return new ChartPanel(chart);
    }
}