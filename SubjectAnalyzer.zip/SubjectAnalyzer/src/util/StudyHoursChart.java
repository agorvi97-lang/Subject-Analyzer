package util;

import model.Student;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.util.List;

public class StudyHoursChart {

    public static JPanel create(List<Student> students){

        XYSeries series = new XYSeries("Students");

        for(Student s : students){

            double hours = s.getStudyHours();
            double score = s.getAverageScore();

            series.add(hours, score);
        }

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);

        JFreeChart chart = ChartFactory.createScatterPlot(
                "Study Hours vs Average Score",
                "Study Hours",
                "Average Score",
                dataset
        );

        return new ChartPanel(chart);
    }
}