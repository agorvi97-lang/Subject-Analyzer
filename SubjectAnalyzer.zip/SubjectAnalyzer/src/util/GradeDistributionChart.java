package util;

import model.Student;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class GradeDistributionChart {

    public static JPanel create(List<Student> students) {
        DefaultPieDataset dataset = new DefaultPieDataset();

        int gradeA = 0, gradeB = 0, gradeC = 0, gradeD = 0, gradeF = 0;

        for (Student s : students) {
            double avg = s.getAverageScore();
            if (avg >= 80) gradeA++;
            else if (avg >= 70) gradeB++;
            else if (avg >= 60) gradeC++;
            else if (avg >= 50) gradeD++;
            else gradeF++;
        }

        dataset.setValue("A", gradeA);
        dataset.setValue("B", gradeB);
        dataset.setValue("C", gradeC);
        dataset.setValue("D", gradeD);
        dataset.setValue("F", gradeF);

        JFreeChart chart = ChartFactory.createPieChart(
                "Grade Distribution",
                dataset,
                true,
                true,
                false
        );

        PiePlot plot = (PiePlot) chart.getPlot();

        // Colors
        plot.setSectionPaint("A", new Color(52, 152, 219));
        plot.setSectionPaint("B", new Color(46, 204, 113));
        plot.setSectionPaint("C", new Color(241, 196, 15));
        plot.setSectionPaint("D", new Color(230, 126, 34));
        plot.setSectionPaint("F", new Color(231, 76, 60));

        // Match dashboard background
        plot.setBackgroundPaint(new Color(245, 245, 245));

        // Show count + percentage in labels
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {1} ({2})"));

        return new ChartPanel(chart);
    }
}