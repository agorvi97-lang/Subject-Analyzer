package util;

import model.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TopStudentsTable {

    public static JScrollPane create(List<Student> s){

        String[] cols={"Rank","Name","Average"};

        DefaultTableModel model=new DefaultTableModel(cols,0);

        List<Student> top=s.stream()
                .sorted(Comparator.comparingDouble(Student::getAverageScore).reversed())
                .limit(10)
                .collect(Collectors.toList());

        int rank=1;

        for(Student st:top){

            model.addRow(new Object[]{
                    rank++,
                    st.getName(),
                    String.format("%.2f",st.getAverageScore())
            });
        }

        JTable table=new JTable(model);

        return new JScrollPane(table);
    }


}