package util;

import model.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class CSVContentTable {

    public static JScrollPane create(List<Student> students) {

        // Columns: match your CSV headers
        String[] cols = {"Name", "Maths", "English", "Science", "Social", "StudyHours"};

        DefaultTableModel model = new DefaultTableModel(cols, 0);

        for (Student s : students) {
            model.addRow(new Object[]{
                    s.getName(),
                    s.getMaths(),
                    s.getEnglish(),
                    s.getScience(),
                    s.getSocial(),
                    s.getStudyHours()
            });
        }

        // Make table read-only
        JTable table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table.setFont(table.getFont().deriveFont(14f));
        table.setRowHeight(24);
        table.getTableHeader().setFont(table.getTableHeader().getFont().deriveFont(java.awt.Font.BOLD, 14f));

        return new JScrollPane(table);
    }
}