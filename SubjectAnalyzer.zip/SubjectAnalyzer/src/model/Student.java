package model;

public class Student {

    private String id;
    private String name;
    private double maths;
    private double english;
    private double science;
    private double social;
    private double studyHours;
    private double attendance;

    public Student(String id,String name,double maths,double english,double science,double social,double studyHours,double attendance){

        this.id=id;
        this.name=name;
        this.maths=maths;
        this.english=english;
        this.science=science;
        this.social=social;
        this.studyHours=studyHours;
        this.attendance=attendance;
    }
    public double getStudyHours(){
        return studyHours;
    }
    public String getName(){
        return name;
    }

    public double getMaths(){
        return maths;
    }

    public double getEnglish(){
        return english;
    }

    public double getScience(){
        return science;
    }

    public double getSocial(){
        return social;
    }

    public double getAverageScore(){
        return (maths+english+science+social)/4;
    }

    public double getScore(String subject){
        switch(subject){
            case "Maths": return maths;
            case "English": return english;
            case "Science": return science;
            case "Social": return social;
            default: return 0;
        }
    }


}